# Python Agent 服务

- Python：3.12
- API：FastAPI 0.158.1
- LangChain：1.2.18（遵循用户指定的 1.2.x 系列）
- LangGraph：1.x 系列
- 数据校验：Pydantic 2.x
- 依赖管理：uv

当前默认使用无外部模型依赖的确定性工作流，保证首次启动不需要 API Key。工作流演示了 LangGraph 状态流转与业务 SOP 工具调用；还没有连接真实标注业务 API、向量数据库或在线模型。

## 本地运行

```bash
uv sync
uv run uvicorn app.main:app --reload --port 8000
uv run pytest
```

OpenAPI 文档：`http://localhost:8000/docs`

## 启用真实模型的后续步骤

设置 `MODEL_ENABLED=true`、`OPENAI_API_KEY` 和 `OPENAI_MODEL`，在 `app/graph/workflow.py` 中加入模型节点。不要把 API Key 放入前端，也不要让模型直接决定用户身份、租户或权限。业务工具必须通过 Go 后端进行鉴权与审计。

## 当前骨架的边界

运行记录和 Trace 暂存在 Python 进程内存，服务重启或多副本部署会丢失/不一致。正式阶段应将 Run/Trace/Checkpoint 持久化，推荐由 Go 的 MySQL 业务库作为查询入口，LangGraph Checkpointer 采用持久化后端，并通过事件表或 Redis Stream/SSE 向前端推送增量事件。
