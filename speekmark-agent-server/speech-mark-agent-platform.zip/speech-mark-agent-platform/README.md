# 语音标注智能体平台（完整工程骨架）

中文 React 管理后台 + Go/Gin/GORM 业务后端 + Python/FastAPI/LangChain/LangGraph Agent + MySQL + Redis。目标是让前端作为可运行的标准客户端，你主要实现 Go 业务能力与 Python Agent 工作流。

## 技术版本（按确认方案锁定）

| 模块 | 版本/范围 | 说明 |
|---|---|---|
| Go | 1.26.10 工具链，`go 1.26.0` 指令 | 已按方案 B 升级 Go |
| Gin | 1.12.0 | 固定版本 |
| GORM | 1.31.2 | 固定版本 |
| MySQL Driver | 1.6.0 | GORM MySQL 驱动 |
| go-redis | 9.22.0 | Redis 客户端；Go 1.26 满足其工具链要求 |
| MySQL | 8.4 LTS | Docker Compose 服务端 |
| Redis | 7.4 | Docker Compose 服务端，启用密码与 AOF |
| Python | 3.12 | 固定 Python 小版本系列 |
| FastAPI | 0.158.1 | 截至 2026-10-22 PyPI 当前版本，支持 Pydantic 2 |
| Pydantic | 2.x | 数据模型和请求校验 |
| LangChain | 1.2.18 | 按要求选择 1.2.x，不追随 1.4.x 最新系列 |
| LangGraph | 1.x | 由 `uv.lock` 锁定解析出的兼容版本 |
| Python 包管理 | uv | 生成 `uv.lock` 后应提交版本库 |
| React | 19.x | 中文管理后台 |
| Ant Design | 5.x | UI 组件库 |
| Vite | 7.x | 前端构建工具 |

版本核对参考：Gin 1.12.0 官方 README；Go 1.26 官方发布记录；FastAPI PyPI 和发布说明；LangChain 1.2.18 PyPI 元数据。请注意 `latest` 会随时间变化，本工程将 FastAPI 固定到当前核对的 0.158.1，避免构建时漂移。参考链接见 `docs/版本与兼容性.md`。

## 目录结构

```text
speech-mark-agent-platform/
├── web/                         # 中文 React 前端，Mock/真实 API 可切换
├── backend-go/                  # Gin + GORM + MySQL + Redis
│   ├── cmd/server/
│   ├── internal/{config,database,handler,middleware,model,repository,service,client}/
│   ├── migrations/
│   ├── go.mod
│   └── Dockerfile
├── agent-python/                # Python 3.12 + FastAPI + LangChain + LangGraph
│   ├── app/{api,core,graph,schemas,services,tools}/
│   ├── tests/
│   ├── pyproject.toml
│   └── Dockerfile
├── deploy/docker-compose.yml
├── docs/                        # API 契约、架构、版本说明
├── .env.example
└── README.md
```

## 一键启动（Docker）

前提：已安装 Docker Desktop / Docker Engine 与 Compose v2。

```bash
cp .env.example .env
# 建议先修改 .env 里的开发密码

docker compose --env-file .env -f deploy/docker-compose.yml up --build
```

- 中文前端：http://localhost:5173
- Go API 健康检查：http://localhost:8080/health/live
- Go 依赖就绪检查：http://localhost:8080/health/ready
- Python Agent OpenAPI：http://localhost:8000/docs（仅容器内网络暴露；本机可通过端口映射临时开放）

默认不要求模型 API Key，Agent 使用确定性 LangGraph 示例工作流。第一次构建需要下载 npm、Go、Python 依赖和镜像。若需在宿主机直接访问 Python 文档，可在 `deploy/docker-compose.yml` 的 agent-python 服务增加 `ports: ["8000:8000"]`。

停止服务：

```bash
docker compose --env-file .env -f deploy/docker-compose.yml down
```

删除数据库数据卷（危险，会清空本地数据）：

```bash
docker compose --env-file .env -f deploy/docker-compose.yml down -v
```

## 本地开发

### 前端

```bash
cd web
cp .env.example .env
npm install
npm run dev
```

### Go

需要 Go 1.26.x。先启动 MySQL 与 Redis，并设置 `MYSQL_DSN`、`REDIS_ADDR`、`REDIS_PASSWORD`、`AGENT_BASE_URL`：

```bash
cd backend-go
go mod tidy
go run ./cmd/server
```

### Python Agent

需要 Python 3.12 与 uv：

```bash
cd agent-python
uv lock
uv sync
uv run uvicorn app.main:app --reload --port 8000
uv run pytest
```

## 前端 Chat 与 Trace 设计

- Chat 采用会话式布局，支持建议问题、输入、发送、停止、运行状态和结果摘要。
- Trace 展示可审计事件：节点、工具调用标识、状态、耗时、输入/输出摘要和异常；不展示隐藏的模型内部推理链。
- 当前实现用轮询更新 Run 和 Trace。后续可在 API 契约不变的前提下增加 SSE，减少轮询延迟。
- 当前 Mock 模式可通过 `VITE_USE_MOCK=true` 独立演示；Docker 默认 `false`，真实请求由 Nginx 转发至 Go。

## 当前实现范围与重要限制

1. Go 已实现健康检查、MySQL/GORM 自动迁移、Redis Ping、运行记录 CRUD 的基础查询、创建/查询/取消 Run、Trace、审批接口和知识库占位接口。
2. Go 创建 Run 后调用 Python Agent。当前 Agent 工作流是同步的确定性演示，不是真正的后台长任务；生产化需要引入持久化队列/任务执行器、LangGraph Checkpointer 和可恢复的取消机制。
3. Python Run 与 Trace 当前保存在进程内存；多副本或重启后不保证存在。MySQL 是 Go 侧的持久化来源，正式实现需把 Agent 事件可靠写入数据库/事件总线。
4. 目前未接真实标注业务 API、向量数据库、登录鉴权或真实模型。所有业务写操作必须由 Go 做权限验证、幂等、审计和审批，不能信任模型输出的 user_id / role / tenant。
5. CORS、Mock 身份等只适合本地开发；上线前必须替换为真实身份认证、授权策略、限流、密钥管理与安全日志。
6. Go 的 AutoMigrate 只为快速启动服务；生产建议改用版本化迁移工具，并先审阅 DDL。

## 接下来推荐的开发顺序

1. 先启动整个工程，验证健康检查与前端 Chat。
2. 把 Go 的 Run/Trace 读写从当前简单 handler 拆到 Service/Repository，并补测试。
3. 设计业务工具的请求/响应与权限边界，再让 Python Agent 通过 Go 调用只读工具。
4. 为 Agent 加入持久化 Checkpoint、事件持久化、SSE 和超时/重试策略。
5. 加入模型提供商配置、RAG/向量检索、评估数据集、观测与成本统计。

## 本次交付验证说明

已通过 JS/JSX、Python 语法检查、Compose YAML 与配置文件解析检查。由于生成环境只有 Go 1.23.2、Python 3.13.5，且无法连接外部依赖仓库，尚未执行真实依赖安装、Go 编译、前端生产构建或 Docker 集成启动；详细记录见 `docs/本次交付验证.md`。在可联网环境首次安装后，请生成并提交 `go.sum`、`uv.lock`、`package-lock.json`。
