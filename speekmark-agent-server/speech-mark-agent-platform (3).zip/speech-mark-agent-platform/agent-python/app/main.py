import logging
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.api.routes import router
from app.core.config import settings

logging.basicConfig(level=getattr(logging, settings.log_level.upper(), logging.INFO), format="%(asctime)s %(levelname)s %(name)s %(message)s")

@asynccontextmanager
async def lifespan(_: FastAPI):
    logging.getLogger(__name__).info("Agent 服务启动；模型调用默认关闭，使用确定性示例工作流")
    yield

app = FastAPI(title=settings.app_name, version="0.1.0", description="面向语音标注业务的 Agent API 骨架", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:5173"], allow_credentials=False, allow_methods=["GET", "POST", "OPTIONS"], allow_headers=["*"])
app.include_router(router)

@app.get("/health/live", tags=["健康检查"])
def liveness() -> dict:
    return {"status": "alive", "service": "agent-python"}

@app.get("/health/ready", tags=["健康检查"])
def readiness() -> dict:
    # Add Redis / model provider checks when those dependencies become mandatory.
    return {"status": "ready", "model_enabled": settings.model_enabled}
