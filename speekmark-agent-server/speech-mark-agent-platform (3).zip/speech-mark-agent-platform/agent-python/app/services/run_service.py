from datetime import UTC, datetime
from time import perf_counter
from uuid import uuid4
from app.graph.workflow import agent_graph
from app.schemas.run import CreateRunRequest, RunResponse, TraceEvent

_RUNS: dict[str, RunResponse] = {}
_TRACES: dict[str, list[TraceEvent]] = {}


def _event(run_id: str, seq: int, kind: str, node: str, title: str, detail: str, duration_ms: int = 0, tool_call_id: str | None = None, input_summary: str | None = None, output_summary: str | None = None) -> TraceEvent:
    return TraceEvent(
        event_id=f"evt_{uuid4().hex}", run_id=run_id, seq=seq, type=kind,
        node=node, title=title, detail=detail, status="succeeded", duration_ms=duration_ms,
        tool_call_id=tool_call_id, input_summary=input_summary, output_summary=output_summary,
        created_at=datetime.now(UTC),
    )


def create_run(req: CreateRunRequest) -> RunResponse:
    run_id = req.run_id or f"run_{uuid4().hex}"
    started = datetime.now(UTC)
    _RUNS[run_id] = RunResponse(run_id=run_id, input=req.input, status="running", started_at=started)
    events = [_event(run_id, 1, "run.started", "agent", "开始执行", "Agent 已接收任务并初始化工作流。")]
    begin = perf_counter()
    try:
        result = agent_graph.invoke({"run_id": run_id, "input": req.input, "mode": req.mode})
        elapsed = int((perf_counter() - begin) * 1000)
        seq = 2
        events.append(_event(run_id, seq, "node.completed", "classify", "识别任务意图", str(result.get("tool_summary", "已完成")), elapsed))
        seq += 1
        tool_count = 0
        if "命中业务知识" in result.get("tool_summary", ""):
            tool_call_id = f"tool_{uuid4().hex[:12]}"
            events.append(_event(run_id, seq, "tool.started", "search_annotation_sop", "调用工具：检索标注规范", "根据用户问题检索示例 SOP。", tool_call_id=tool_call_id, input_summary=req.input))
            seq += 1
            events.append(_event(run_id, seq, "tool.completed", "search_annotation_sop", "工具返回检索结果", "已从示例知识库返回一条规范摘要。", tool_call_id=tool_call_id, input_summary=req.input, output_summary="返回一条 SOP 示例摘要"))
            seq += 1
            tool_count = 1
        events.append(_event(run_id, seq, "node.completed", "respond", "生成回答", "已生成最终答复。"))
        seq += 1
        finished = datetime.now(UTC)
        run = RunResponse(run_id=run_id, input=req.input, status="succeeded", final_answer=result.get("answer"), started_at=started, finished_at=finished, duration_ms=int((finished-started).total_seconds()*1000), steps=seq, tools=tool_count, tokens=0)
        events.append(_event(run_id, seq, "run.completed", "agent", "任务执行完成", "工作流已结束。", run.duration_ms))
        _RUNS[run_id] = run
    except Exception as exc:  # noqa: BLE001 - surfaced as a sanitized run error in this learning scaffold
        finished = datetime.now(UTC)
        _RUNS[run_id] = RunResponse(run_id=run_id, input=req.input, status="failed", error="Agent 工作流执行失败", started_at=started, finished_at=finished, duration_ms=int((finished-started).total_seconds()*1000))
        events.append(_event(run_id, 4, "run.failed", "agent", "任务执行失败", type(exc).__name__))
    _TRACES[run_id] = events
    return _RUNS[run_id]


def get_run(run_id: str) -> RunResponse | None:
    return _RUNS.get(run_id)


def get_trace(run_id: str) -> list[TraceEvent] | None:
    return _TRACES.get(run_id)
