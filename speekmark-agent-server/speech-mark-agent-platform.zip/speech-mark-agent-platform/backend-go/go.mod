module example.com/speech-mark-agent-platform/backend-go

go 1.26.0

toolchain go1.26.10

require (
	github.com/gin-gonic/gin v1.12.0
	github.com/redis/go-redis/v9 v9.22.0
	gorm.io/driver/mysql v1.6.0
	gorm.io/gorm v1.31.2
	github.com/google/uuid v1.6.0
	github.com/joho/godotenv v1.5.1
)
