package config

import (
	"os"
	"time"

	"github.com/joho/godotenv"
)

type Config struct {
	Port, GinMode, DatabaseDriver, SQLitePath, MySQLDSN, RedisAddr, RedisPassword, RedisDB, AgentBaseURL, Environment string
	AgentTimeout                                                                                                      time.Duration
}

func Load() Config {
	_ = godotenv.Load(".env", "../.env", "../../.env")
	return Config{
		Port: env("GO_PORT", "8080"), GinMode: env("GIN_MODE", "debug"),
		DatabaseDriver: env("DATABASE_DRIVER", "sqlite"), SQLitePath: env("SQLITE_PATH", "./data/agent_platform.db"),
		MySQLDSN:  env("MYSQL_DSN", "agent:agent_dev_password@tcp(mysql:3306)/agent_platform?charset=utf8mb4&parseTime=True&loc=Local"),
		RedisAddr: env("REDIS_ADDR", "redis:6379"), RedisPassword: env("REDIS_PASSWORD", "dev_redis_password"), RedisDB: env("REDIS_DB", "0"),
		AgentBaseURL: env("AGENT_BASE_URL", "http://agent-python:8000"), Environment: env("APP_ENV", "development"),
		AgentTimeout: 45 * time.Second,
	}
}

func env(key, fallback string) string {
	if v := os.Getenv(key); v != "" {
		return v
	}
	return fallback
}
