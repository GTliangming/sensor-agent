module example.com/speech-mark-agent-platform/backend-go

go 1.23.0

require (
	github.com/gin-gonic/gin v1.11.0
	github.com/google/uuid v1.6.0
	github.com/joho/godotenv v1.5.1
	gorm.io/driver/sqlite v1.6.0
	gorm.io/gorm v1.31.2
)
