from langgraph.graph import END, START, StateGraph
from app.graph.state import AgentState
from app.tools.registry import TOOLS


def classify_node(state: AgentState) -> AgentState:
    text = state.get("input", "")
    if any(word in text for word in ("SOP", "标准", "切分", "质检", "规范")):
        return {"tool_summary": "命中业务知识检索意图"}
    return {"tool_summary": "当前为基础示例工作流；真实业务查询需接入 Go 授权 API"}


def respond_node(state: AgentState) -> AgentState:
    text = state.get("input", "")
    if any(word in text for word in ("SOP", "标准", "切分", "质检", "规范")):
        tool_result = TOOLS[0].invoke({"query": text})
        answer = f"根据当前示例知识库：\n\n{tool_result}\n\n说明：这是演示数据，尚未连接真实业务数据库。"
    else:
        answer = (
            "我已收到你的任务。当前项目骨架已完成工作流路由，但尚未连接真实标注业务 API 或在线大模型。\n\n"
            "下一步可以在 Go 后端实现只读业务查询工具，再由 Agent 在服务端完成权限校验、数据查询和结果归纳。"
        )
    return {"answer": answer}


def build_graph():
    graph = StateGraph(AgentState)
    graph.add_node("classify", classify_node)
    graph.add_node("respond", respond_node)
    graph.add_edge(START, "classify")
    graph.add_edge("classify", "respond")
    graph.add_edge("respond", END)
    return graph.compile()


agent_graph = build_graph()
