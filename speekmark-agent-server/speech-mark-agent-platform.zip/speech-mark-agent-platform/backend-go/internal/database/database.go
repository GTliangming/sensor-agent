package database

import (
	"context"
	"fmt"
	"time"

	"example.com/speech-mark-agent-platform/backend-go/internal/config"
	"example.com/speech-mark-agent-platform/backend-go/internal/model"
	"github.com/redis/go-redis/v9"
	mysqlDriver "gorm.io/driver/mysql"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"
)

func OpenMySQL(cfg config.Config) (*gorm.DB, error) {
	level := logger.Warn
	if cfg.GinMode == "debug" {
		level = logger.Info
	}
	db, err := gorm.Open(mysqlDriver.Open(cfg.MySQLDSN), &gorm.Config{Logger: logger.Default.LogMode(level)})
	if err != nil {
		return nil, err
	}
	sqlDB, err := db.DB()
	if err != nil {
		return nil, err
	}
	sqlDB.SetMaxOpenConns(30)
	sqlDB.SetMaxIdleConns(10)
	sqlDB.SetConnMaxLifetime(30 * time.Minute)
	if err = sqlDB.Ping(); err != nil {
		return nil, err
	}
	if err = db.AutoMigrate(&model.AgentRun{}, &model.TraceEvent{}, &model.Approval{}); err != nil {
		return nil, fmt.Errorf("自动迁移失败: %w", err)
	}
	return db, nil
}
func OpenRedis(cfg config.Config) (*redis.Client, error) {
	// RedisDB is parsed defensively so an invalid env value doesn't crash startup.
	var db int
	_, _ = fmt.Sscanf(cfg.RedisDB, "%d", &db)
	c := redis.NewClient(&redis.Options{Addr: cfg.RedisAddr, Password: cfg.RedisPassword, DB: db, DialTimeout: 3 * time.Second, ReadTimeout: 3 * time.Second, WriteTimeout: 3 * time.Second})
	if err := c.Ping(context.Background()).Err(); err != nil {
		_ = c.Close()
		return nil, err
	}
	return c, nil
}
