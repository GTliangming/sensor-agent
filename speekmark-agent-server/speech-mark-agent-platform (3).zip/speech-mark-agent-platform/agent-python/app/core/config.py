from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    app_name: str = "语音标注 Agent 服务"
    app_env: str = "development"
    log_level: str = "INFO"
    agent_port: int = 8000
    redis_url: str = "redis://:dev_redis_password@redis:6379/1"
    openai_api_key: str = ""
    openai_base_url: str = ""
    openai_model: str = "gpt-4.1-mini"
    model_enabled: bool = False
    go_backend_base_url: str = "http://backend-go:8080/api/v1"
    request_timeout_seconds: float = 30.0
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
